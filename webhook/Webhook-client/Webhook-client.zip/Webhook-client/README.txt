#Introduction
You only need to do the following 2 steps to
connect your webhook to Real Time Chat.

STEP 1:Host your webhook and do a few settings.
Download the webhook.zip and extract it, thenclick
the run.bat file in the folder.
(You may need to modify the host IP in some cases,
just make sure you can access your webhook server
throw the internet.)

STEP 2:Register your webhook.
Go to https://realtimechat.ddns.net and enter any
room then type !webhook. And click "Register your
host". That's it!